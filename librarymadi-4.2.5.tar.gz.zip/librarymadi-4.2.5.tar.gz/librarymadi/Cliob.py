#Copyright (C) 2022 madiBOT

version= "4.2.5"
copyright = " madi Copyright (C) 2022 arianabasi Team madiBOT \n\n"
Arian = "madiBOT"

class chup:
	pchap = print(f"Arsein library version {version}\n{copyright}\n☞ library Arsein: https://github.com/Arseinlibrary/Arsein__library.git\n\nدر حال فعال شدن کمی صبور باشید...\n")
	print(" ")
	print(". . . . . . . . . . . ")

