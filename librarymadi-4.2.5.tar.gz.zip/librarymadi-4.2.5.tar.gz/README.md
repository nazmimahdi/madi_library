How to import madi's library is as follows:

<< from librarymadi.madi import Robot_Rubika >>

An example:

from librarymadi.madi import Robot_Rubika

bot = Robot_Rubika("Your Auth Account")


Made by Team ArianBot

Address of our team's GitHub :

https://github.com/nazmimahdi/madi_library#madi_library